# Towers of Hanoi - Pygame

Towers of Hanoi puzzle as a game using python3 and pygame

## How to play

You need pygame installed with python 3. On Windows, simply double-click the file. On Linux-based systems, use the command line.

On the title screen, use arrow keys to select the number of disks, then press ENTER to start. In game, use the LEFT and RIGHT arrow keys to move the pointer, and UP and DOWN arrows to lift and place disks.

Press ESCAPE to return to the menu screen and Q to quit the game.